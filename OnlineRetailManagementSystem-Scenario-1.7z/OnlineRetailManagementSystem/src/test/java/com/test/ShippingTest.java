package com.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import com.retail.shipping.ShippingService;

public class ShippingTest {

    @Test
    void testShipOrder() {
            ShippingService shippingService = new ShippingService();
            assertDoesNotThrow(() -> shippingService.shipOrder(1));
        }
    }

