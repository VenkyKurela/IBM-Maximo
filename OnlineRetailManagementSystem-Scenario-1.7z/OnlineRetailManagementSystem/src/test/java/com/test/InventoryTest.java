package com.test;

import static org.junit.jupiter.api.Assertions.*;

import com.retail.inventory.Inventory;
import org.junit.jupiter.api.Test;

public class InventoryTest {

@Test
void testAddStock() {
    Inventory inventory = new Inventory();
            inventory.addStock(101, 10);
            assertTrue(inventory.fulfillOrder(101, 5));
        }

        @Test
        void testOutOfStock() {
            Inventory inventory = new Inventory();
            assertFalse(inventory.fulfillOrder(999, 1));
        }
    }

