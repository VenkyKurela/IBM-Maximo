package com.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import com.retail.product.Electronics;
import com.retail.product.Clothing;
public class ProductTest {
 @Test
 void testElectronicsProduct() {
            Electronics laptop = new Electronics(101, "Laptop", 1200.00, "Dell");
            assertEquals(101, laptop.productId);
            assertEquals("Laptop", laptop.productName);
            assertEquals(1200.00, laptop.price);
        }

        @Test
        void testClothingProduct() {
            Clothing tshirt = new Clothing(102, "T-Shirt", 20.00, "M");
            assertEquals("M", tshirt.size);
        }
    }

