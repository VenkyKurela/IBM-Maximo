package com.retail.inventory;

import java.util.HashMap;
import java.util.Map;

public class Inventory {

    private Map<Integer, Integer> stock = new HashMap<>();

        public void addStock(int productId, int quantity) {
            stock.put(productId, stock.getOrDefault(productId, 0) + quantity);
        }

        public boolean fulfillOrder(int productId, int quantity) {
            if (stock.getOrDefault(productId, 0) >= quantity) {
                stock.put(productId, stock.get(productId) - quantity);
                return true;
            } else {
                System.out.println("Error: Product out of stock!");
                return false;
            }
        }
    }


