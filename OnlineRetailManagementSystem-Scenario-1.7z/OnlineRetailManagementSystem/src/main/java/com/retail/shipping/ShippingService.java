package com.retail.shipping;

public class ShippingService {

    public void shipOrder(int orderId) {
        System.out.println("Order " + orderId + " has been shipped!");
    }

}
