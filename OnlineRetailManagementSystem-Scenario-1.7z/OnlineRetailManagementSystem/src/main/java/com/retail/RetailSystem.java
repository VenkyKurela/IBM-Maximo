package com.retail;

import com.retail.inventory.Inventory;
import com.retail.product.Clothing;
import com.retail.product.Electronics;
import com.retail.shipping.ShippingService;

public class RetailSystem {

        public static void main(String[] args) {
            Electronics laptop = new Electronics(101, "Laptop", 1200.00, "Dell");
            Clothing tshirt = new Clothing(102, "T-Shirt", 20.00, "M");

            Inventory inventory = new Inventory();
            inventory.addStock(101, 10);
            inventory.addStock(102, 5);

            laptop.displayProductDetails();
            tshirt.displayProductDetails();

            if (inventory.fulfillOrder(101, 2)) {
                ShippingService shippingService = new ShippingService();
                shippingService.shipOrder(1);

            }
        }
    }
