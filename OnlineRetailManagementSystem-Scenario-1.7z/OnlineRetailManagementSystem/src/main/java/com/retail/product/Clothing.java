package com.retail.product;

public class Clothing extends Product {
        public String size;

        public Clothing(int productId, String productName, double price, String size) {
            super(productId, productName, price);
            this.size = size;
        }

        @Override
        public void displayProductDetails() {
            super.displayProductDetails();
            System.out.println("Size: " + size);
        }
    }
