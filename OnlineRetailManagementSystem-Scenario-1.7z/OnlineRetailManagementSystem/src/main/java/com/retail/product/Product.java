package com.retail.product;

public class Product {
    public int productId;
    public String productName;
    public double price;

    public Product(int productId, String productName, double price) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        }
    public void displayProductDetails() {
            System.out.println("Product ID: " + productId);
            System.out.println("Product Name: " + productName);
            System.out.println("Price: " + price+" Rupees");
        }
    }


