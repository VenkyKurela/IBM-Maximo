package com.retail.product;

public class Electronics extends Product {
        private String brand;

        public Electronics(int productId, String productName, double price, String brand) {
            super(productId, productName, price);
            this.brand = brand;
        }

        @Override
        public void displayProductDetails() {
            super.displayProductDetails();
            System.out.println("Brand: " + brand);
        }
    }
